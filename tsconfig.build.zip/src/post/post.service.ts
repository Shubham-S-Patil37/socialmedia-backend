import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { UserModel, IUser } from 'database/schema/user';
import { IPost, PostModel } from 'database/schema/post';


@Injectable()
export class PostService {

  async getUserPost(userId: string) {
    try {
      const post: IPost[] = await PostModel.find({ userId: userId });

      console.log(post)
      post.map(ele => {
        ele.media = process.env.INSTANCE_URL + 'uploads/' + ele.media
      })

      const data = {
        totalPost: post.length,
        post: post
      }

      return { data: data, message: "User post fined", statusCode: HttpStatus.OK }
    }
    catch (error) {
      if (error instanceof HttpException) throw error;
      throw new HttpException({ statusCode: HttpStatus.INTERNAL_SERVER_ERROR, message: 'An unexpected error occurred ' + error.message, }, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  async createPost(userId: string, postTitle: string, file: Express.Multer.File) {
    try {
      if (!postTitle)
        throw new HttpException({ statusCode: HttpStatus.BAD_REQUEST, message: 'The request is missing a title', }, HttpStatus.BAD_REQUEST);

      const postDetails: IPost = new PostModel()
      postDetails.title = postTitle
      postDetails.userId = userId;
      postDetails.media = file.filename;
      postDetails.isActive = true;


      postDetails.save()
      return { data: {}, message: "User post Created", statusCode: HttpStatus.OK }

    }
    catch (error) {
      if (error instanceof HttpException) throw error;
      throw new HttpException({ statusCode: HttpStatus.INTERNAL_SERVER_ERROR, message: 'An unexpected error occurred ' + error.message, }, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }


}